lcdproc.cps Readme
==================

1) Install
~~~~~~~~~~~

This is the lcdproc package for use with Coyote Package System and
Coyote Linux 1.3 or less.  This package currently does not work with
Coyote Linux 1.4 or greater, sorry!

Please choose your LCD type below to find out what driver to use.
Then navigate to that directory and you will find the needed .cps
package.  Place your .cps package on a floppy disk and following
standard CPS proceedure, install the lcdproc.cps package on your
router.


LCD Module / Driver             Directory
-------------------------------------------
Bayrad                          bayrad
Crystal Fontz                   cfontz
Cwlinux                         cwlnx
Hitachi HD44780                 hd44780
PIC-an-LCD                      hd44780
LCDM001                         lcdm001
Matrix Orbital                  mtxorb
Matrix Orbital GLK              mtxorb
Seiko Epson 1330                sed
Seiko Epson 1520                sed
STV5730                         stv5730
SGX120                          sgx120
Toshiba T6963                   T6963
Wirz SLI LCD                    wirz
(all of the above)              all



2) Why is it packaged like this?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

To save space!  Anyone who has used CPS knows that the standard Coyote Linux
install doesn't allow much in the way of extra space due to it's floppy disk
limits.  When I compiled the LCDd binary with all the drivers, it was nearly 200k
and that is just to big for a simple app.  So I compiled the binary with only
the needed drivers for each type of LCD.  Now most of the LCDd binaries are around
100k only making the compressed CPS package usually under 100k.  Why waste that
valuable space for drivers that your not going to use anyway?  Just install the
package that is for your LCD and your on your way!  Saving space for other
CPS packs ;)


3) Extra Help
~~~~~~~~~~~~~

The LCDproc manual can be found at
http://lcdproc.sourceforge.net/docs/stable-0-4-4-user-html/

Other help is available by installing the package and reading the help file.

Enjoy!


4) Changelog
~~~~~~~~~~~~

Version 1.0
-----------
- Updated LCDproc server and client to version 0.4.5 (from 0.4.3) because
   of a major memory leak!
- Support for Wirz-sli, sgx120, cwlinux and USB Crystal Fonts LCD's was added thanks
   to the new LCDproc version.
- Better support for existing LCD added thanks to the new LCDproc version.